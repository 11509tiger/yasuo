
# attend

> a vue2.0 project, use webpack to pack

## Build Setup
    
    # install dependencies
    npm install

    # serve with hot reload at localhost:8080
    npm start

    # build for production with minification
    npm run build
    

For detailed explanation on how things work, consult the [docs for vue2.0](http://cn.vuejs.org/v2/guide/).


