define(function (require) {
	return  function(){
		alert('hello ')
	}
})